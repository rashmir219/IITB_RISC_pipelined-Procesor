# EE 309 Pipelined RISC

This repository contains complete code of EE 309 Course Project II. Please refer to report to understand the architecture, the data flow and the control flow.

## Note to Junior Students

Hey there!! Please do not use this code in your submission. I (and my team) spent a week coding this up, debugging and making it work. The ideation and the design took another week. Don't try to make your life easier using this. It wont get easier dear. All the submitted codes and designs are checked for Plagarism by TAs of the course, and the Professor himself. Code this up and you'll be real happy. You can refer the report to get an **idea** of how the implementation is done. Enjoy!

